---
name: memory-capture
description: >
  Capture a new atomic fact into Repository Memory (Common Law) via
  scripts/memory.py. Use in exactly three situations: (1) the user CHALLENGES a
  prior outcome in their prompt — record the corrected understanding, run in the
  BACKGROUND so the main task keeps moving; (2) a statement in a CLAUDE.md
  (Constitution or Legislation) is CLARIFIED — explained, not changed — record
  the clarified interpretation; (3) net-new KNOWLEDGE relevant to the workspace
  topic is provided and the conversation shows the model did not know it prior —
  record the learned fact, tag `knowledge`, run in the BACKGROUND. Never used to
  change a rule; only to record a learned fact. All writes go through
  scripts/memory.py (the OKF schema gate).
---

# Capture a learned fact

Turn a moment of learning into one atomic, reusable OKF fact. Writes go only
through the single point of contact, which enforces the schema and blocks
personal/secret content:

    {{PYTHON}} scripts/memory.py create --id <kebab-id> --tags <tag[,tag]> \
        --keywords <k1,k2> --scope <{{SCOPES}}> \
        --fact "<one sentence, <=240 chars, ends with a full stop>" \
        [--context "<<=10 lines of how-to-apply detail>"]

## Mode 1 — a challenge (run ASYNC)

When the user challenges an outcome (they say it's wrong, question why you did
something, or correct your result):

1. First **resolve the challenge in the main flow** — the user's task comes first.
2. Then spawn the capture as a **background subagent** (Agent tool,
   `run_in_background: true`) so the conversation keeps moving. The subagent:
   - distils the corrected understanding into ONE fact, tag **`fix`** (or
     `issue` if it's a newly-found problem not yet fixed);
   - `search`es first — if a near-duplicate exists, `update` it instead of
     creating a second;
   - writes it via `memory.py create`.
3. Do not make the user wait on the capture.

## Mode 2 — a CLAUDE.md clarification (not a change)

When a Constitution/Legislation statement is *clarified* — the user explains
what an existing rule means, without changing or pivoting from it — record the
clarified interpretation so it isn't re-litigated:

- tag **`example`** (a worked interpretation) or `preference`;
- `--scope` = the unit the CLAUDE.md governs (repo for the Constitution);
- link the fact body to the rule in prose ("clarifies the <unit> Legislation's
  <rule>: …");
- this does NOT edit the CLAUDE.md — if the rule itself should change, that's a
  Constitution/Legislation edit, not a memory capture.

## Mode 3 — net-new knowledge (run ASYNC)

When knowledge relevant to the workspace topic is supplied *and the conversation
shows it was not already known to the model* — a domain fact, a system's actual
behaviour, a constraint, or a relationship the model got wrong or plainly
lacked — record it so it need not be re-supplied next session.

The net-new test is **conversational, not introspective**: capture only when the
transcript itself shows the gap — the model asked and was told, guessed wrong
and was corrected, or was handed a fact it evidently did not have. Do not judge
against training knowledge; if there is no visible gap in the conversation, do
not capture. General knowledge the model already had is not Common Law and only
bloats the corpus.

1. Do not block the conversation — spawn the capture as a **background subagent**
   (Agent tool, `run_in_background: true`).
2. The subagent:
   - distils the supplied knowledge into ONE atomic fact, tag **`knowledge`**;
   - `--scope` = the unit the knowledge pertains to (repo for cross-cutting);
   - `search`es first — if a near-duplicate exists, `update` it (refining it if
     the new information is sharper) instead of creating a second;
   - writes it via `memory.py create`.
3. Capture the knowledge, not the conversation around it — the fact should read
   as a standing truth about the workspace, not as "the user told me X".

The line against Mode 2: Mode 2 *interprets an existing rule*; Mode 3 *records a
fact the Legislation never covered*. If the knowledge implies a rule **should**
exist, that's a Legislation edit, not a capture.

## Rules

- ONE fact per capture (the gate rejects multi-sentence facts). Split extras.
- Never include personal/secret data — the gate blocks it, and it must never be
  in shareable repo memory anyway (Constitution law 1).
- After any capture, `memory.py` regenerates `MEMORY.md` automatically.
