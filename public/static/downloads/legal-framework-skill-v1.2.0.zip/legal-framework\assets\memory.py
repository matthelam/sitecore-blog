r"""Repository Memory — the single point of contact for the Common Law layer.

Implements the Legal Framework (see the root CLAUDE.md): Constitution (root
CLAUDE.md) -> Legislation (per-directory CLAUDE.md) -> Common Law (memory/ —
accumulated experience as ATOMIC facts, consulted at Ambiguity Events when
Legislation is unclear). Conceptually the facts are the project's Issues,
Learnings, and Resolutions; mechanically they carry the fixed tag taxonomy
below (issue / fix / preference / example / verification / knowledge).

Every fact file follows the OKF standard — One Key Fact:
  * exactly ONE atomic fact per file: a single sentence, <= 240 chars,
    present tense, specific (the CRUD tool enforces the mechanical parts);
  * schema'd frontmatter: id, tags (from the fixed taxonomy), keywords,
    scope, status, dates;
  * optional short "## Context" (<= 10 lines) for how-to-apply detail.

ALL memory changes go through this tool — it validates the schema BEFORE any
write lands, and regenerates the MEMORY.md index atomically, so the index and
the OKF standard cannot drift. `lint` is the enforcement gate: run it before
committing (Constitution pre-commit ritual) and in any CI.

Usage:
  python scripts/memory.py create --id <kebab-id> --tags preference \
      --keywords k1,k2 --scope repo \
      --fact "<one sentence, <=240 chars, ends with a full stop>" \
      [--context "..."]
  python scripts/memory.py search "<keywords>" [--tags fix] [--scope <unit>] [--top 5]
  python scripts/memory.py read <id> | update <id> ... | supersede <id> [--by <id>] | delete <id>
  python scripts/memory.py lint | reindex | list
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import date
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[1]
MEMORY_DIR = REPO / "memory"
INDEX = REPO / "MEMORY.md"

# ---------------------------------------------------------------------------
# PER-PROJECT CONFIG — set by the legal-framework scaffold; everything else in
# this file is fixed machinery, identical across installations.
#
# SCOPES: "repo" + one scope per Legislation unit (+ "docs" if the project
#         keeps governed docs). Must track the Legislation index in CLAUDE.md.
# PRIVACY_MARKERS: lowercase substrings that must never appear in committed
#         memory (repo memory is shareable by design). A floor, not a scanner.
SCOPES = ("repo", "docs")
PRIVACY_MARKERS = ("password", "api key", "api_key", "secret")
# ---------------------------------------------------------------------------

# Framework version of this installation. Read by the legal-framework skill's
# Upgrade mode to decide which migrations to apply. Bump only via that skill.
FRAMEWORK_VERSION = "1.2.0"

TAGS = ("verification", "issue", "fix", "preference", "example", "knowledge")
STATUSES = ("active", "superseded")
FACT_MAX = 240
CONTEXT_MAX_LINES = 10
ID_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


class OkfError(Exception):
    pass


# ---------------------------------------------------------------- parsing

def parse(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        raise OkfError(f"{path.name}: missing frontmatter block")
    meta = yaml.safe_load(m.group(1)) or {}
    body = m.group(2).strip()
    if "\n## Context\n" in "\n" + body:
        fact, _, context = ("\n" + body).partition("\n## Context\n")
        fact, context = fact.strip(), context.strip()
    else:
        fact, context = body, ""
    return {"meta": meta, "fact": fact, "context": context, "path": path}


def validate(doc: dict) -> list[str]:
    """The OKF gate. Returns violations (empty = compliant)."""
    errs: list[str] = []
    meta, fact, context = doc["meta"], doc["fact"], doc["context"]
    name = doc["path"].name

    fid = meta.get("id", "")
    if not ID_RE.match(str(fid)):
        errs.append(f"{name}: id must be kebab-case, got {fid!r}")
    if doc["path"].stem != fid:
        errs.append(f"{name}: filename must equal id ({fid!r})")
    tags = meta.get("tags") or []
    if not tags or not all(t in TAGS for t in tags):
        errs.append(f"{name}: tags must be non-empty, from {TAGS}")
    kws = meta.get("keywords") or []
    if not kws or not all(isinstance(k, str) and k.strip() for k in kws):
        errs.append(f"{name}: keywords must be a non-empty string list")
    if meta.get("scope") not in SCOPES:
        errs.append(f"{name}: scope must be one of {SCOPES}")
    if meta.get("status") not in STATUSES:
        errs.append(f"{name}: status must be one of {STATUSES}")
    for k in ("created", "updated"):
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(meta.get(k, ""))):
            errs.append(f"{name}: {k} must be YYYY-MM-DD")

    # the One Key Fact: a single short sentence
    if not fact:
        errs.append(f"{name}: missing the key fact")
    else:
        if len(fact) > FACT_MAX:
            errs.append(f"{name}: fact exceeds {FACT_MAX} chars ({len(fact)})")
        if "\n" in fact:
            errs.append(f"{name}: fact must be a single line")
        if not fact.endswith((".", "!", ")")):
            errs.append(f"{name}: fact must end with a full stop")
        if re.search(r"\.\s+[A-Z0-9]", fact):
            errs.append(f"{name}: fact must be ONE sentence (split extras "
                        "into their own facts or Context)")
    if context and len(context.splitlines()) > CONTEXT_MAX_LINES:
        errs.append(f"{name}: Context exceeds {CONTEXT_MAX_LINES} lines")
    # privacy floor: no obvious personal/secret markers in committed memory
    lowered = (fact + " " + context).lower()
    for marker in PRIVACY_MARKERS:
        if marker in lowered:
            errs.append(f"{name}: possible personal/secret content ({marker!r})"
                        " — repo memory must stay shareable")
    return errs


def load_all() -> list[dict]:
    if not MEMORY_DIR.exists():
        return []
    docs = []
    for p in sorted(MEMORY_DIR.glob("*.md")):
        docs.append(parse(p))
    return docs


def lint_all(docs: list[dict] | None = None) -> list[str]:
    docs = docs if docs is not None else load_all()
    errs: list[str] = []
    seen: dict[str, str] = {}
    for d in docs:
        errs += validate(d)
        fid = str(d["meta"].get("id"))
        if fid in seen:
            errs.append(f"duplicate id {fid!r} in {seen[fid]} and {d['path'].name}")
        seen[fid] = d["path"].name
    # index freshness
    if docs and INDEX.exists() and render_index(docs) != INDEX.read_text(encoding="utf-8"):
        errs.append("MEMORY.md is stale — run: python scripts/memory.py reindex")
    return errs


# ---------------------------------------------------------------- writing

def compose(meta: dict, fact: str, context: str) -> str:
    fm = yaml.safe_dump(meta, sort_keys=False, allow_unicode=True).strip()
    body = fact if not context else f"{fact}\n\n## Context\n{context}"
    return f"---\n{fm}\n---\n{body}\n"


def write_fact(meta: dict, fact: str, context: str) -> Path:
    """Validate-then-write: a non-compliant fact never lands on disk."""
    path = MEMORY_DIR / f"{meta['id']}.md"
    candidate = {"meta": meta, "fact": fact.strip(),
                 "context": context.strip(), "path": path}
    errs = validate(candidate)
    if errs:
        raise OkfError("OKF violation(s):\n  " + "\n  ".join(errs))
    MEMORY_DIR.mkdir(exist_ok=True)
    path.write_text(compose(meta, fact.strip(), context.strip()),
                    encoding="utf-8")
    reindex()
    return path


def render_index(docs: list[dict]) -> str:
    lines = [
        "# Repository Memory — Common Law index",
        "",
        "<!-- GENERATED by scripts/memory.py — DO NOT EDIT BY HAND. -->",
        "<!-- All memory CRUD goes through scripts/memory.py (the OKF gate). -->",
        "",
        "One Key Fact per file under `memory/`. Consult at **Ambiguity",
        "Events** — when the Legislation (directory CLAUDE.md) doesn't answer,",
        "query before guessing:",
        "",
        "    python scripts/memory.py search \"<keywords>\" [--tags fix] [--scope <unit>]",
        "",
    ]
    active = [d for d in docs if d["meta"].get("status") == "active"]
    superseded = [d for d in docs if d["meta"].get("status") != "active"]
    for scope in SCOPES:
        rows = [d for d in active if d["meta"].get("scope") == scope]
        if not rows:
            continue
        lines.append(f"## {scope}")
        for d in rows:
            tags = ",".join(d["meta"].get("tags", []))
            lines.append(f"- **{d['meta']['id']}** [{tags}] — {d['fact']}")
        lines.append("")
    if superseded:
        lines.append(f"_{len(superseded)} superseded fact(s) retained for history._")
        lines.append("")
    return "\n".join(lines)


def reindex() -> None:
    INDEX.write_text(render_index(load_all()), encoding="utf-8")


# ---------------------------------------------------------------- search

def search(query: str, tags: list[str], scope: str | None,
           top: int, include_superseded: bool = False) -> list[tuple[float, dict]]:
    terms = [t.lower() for t in re.split(r"[,\s]+", query) if t.strip()]
    hits = []
    for d in load_all():
        meta = d["meta"]
        if not include_superseded and meta.get("status") != "active":
            continue
        if tags and not set(tags) & set(meta.get("tags", [])):
            continue
        if scope and meta.get("scope") not in (scope, "repo"):
            continue
        score = 0.0
        kws = [k.lower() for k in meta.get("keywords", [])]
        fact_l, ctx_l, id_l = d["fact"].lower(), d["context"].lower(), meta["id"]
        for t in terms:
            if t in kws:
                score += 3
            if t in fact_l:
                score += 2
            if t in id_l:
                score += 1
            if t in ctx_l:
                score += 1
        if score > 0:
            hits.append((score, d))
    hits.sort(key=lambda h: -h[0])
    return hits[:top]


# ---------------------------------------------------------------- CLI

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="memory.py", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("create")
    c.add_argument("--id", required=True)
    c.add_argument("--tags", required=True, help="comma-sep from " + ",".join(TAGS))
    c.add_argument("--keywords", required=True, help="comma-sep")
    c.add_argument("--scope", required=True, choices=SCOPES)
    c.add_argument("--fact", required=True)
    c.add_argument("--context", default="")

    u = sub.add_parser("update")
    u.add_argument("id")
    u.add_argument("--fact")
    u.add_argument("--tags")
    u.add_argument("--keywords")
    u.add_argument("--context")

    for name in ("read", "delete"):
        p = sub.add_parser(name)
        p.add_argument("id")

    sp = sub.add_parser("supersede")
    sp.add_argument("id")
    sp.add_argument("--by", default="")

    s = sub.add_parser("search")
    s.add_argument("query")
    s.add_argument("--tags", default="")
    s.add_argument("--scope", default=None, choices=(*SCOPES, None))
    s.add_argument("--top", type=int, default=5)

    sub.add_parser("lint")
    sub.add_parser("reindex")
    sub.add_parser("list")

    a = ap.parse_args(argv)
    today = date.today().isoformat()

    def _find(fid: str) -> dict:
        for d in load_all():
            if d["meta"].get("id") == fid:
                return d
        raise OkfError(f"no fact with id {fid!r}")

    try:
        if a.cmd == "create":
            meta = {"id": a.id, "tags": [t.strip() for t in a.tags.split(",") if t.strip()],
                    "keywords": [k.strip() for k in a.keywords.split(",") if k.strip()],
                    "scope": a.scope, "status": "active",
                    "created": today, "updated": today}
            path = write_fact(meta, a.fact, a.context)
            print(f"created {path.relative_to(REPO)}")
        elif a.cmd == "update":
            d = _find(a.id)
            meta = dict(d["meta"])
            meta["updated"] = today
            if a.tags:
                meta["tags"] = [t.strip() for t in a.tags.split(",") if t.strip()]
            if a.keywords:
                meta["keywords"] = [k.strip() for k in a.keywords.split(",") if k.strip()]
            write_fact(meta, a.fact or d["fact"],
                       a.context if a.context is not None else d["context"])
            print(f"updated {a.id}")
        elif a.cmd == "supersede":
            d = _find(a.id)
            meta = dict(d["meta"])
            meta["status"] = "superseded"
            meta["updated"] = today
            if a.by:
                meta["superseded_by"] = a.by
            # superseded facts bypass the active gate but keep structure valid
            path = d["path"]
            path.write_text(compose(meta, d["fact"], d["context"]), encoding="utf-8")
            reindex()
            print(f"superseded {a.id}" + (f" by {a.by}" if a.by else ""))
        elif a.cmd == "read":
            d = _find(a.id)
            print(d["path"].read_text(encoding="utf-8"))
        elif a.cmd == "delete":
            d = _find(a.id)
            d["path"].unlink()
            reindex()
            print(f"deleted {a.id}")
        elif a.cmd == "search":
            tags = [t.strip() for t in a.tags.split(",") if t.strip()]
            hits = search(a.query, tags, a.scope, a.top)
            if not hits:
                print("no matching facts")
            for score, d in hits:
                tagstr = ",".join(d["meta"].get("tags", []))
                print(f"[{score:>4.1f}] {d['meta']['id']} ({d['meta']['scope']}/{tagstr})")
                print(f"       {d['fact']}")
        elif a.cmd == "lint":
            errs = lint_all()
            if errs:
                print("OKF LINT FAILED:")
                for e in errs:
                    print("  " + e)
                return 1
            print(f"OKF lint OK ({len(load_all())} fact(s))")
        elif a.cmd == "reindex":
            reindex()
            print("MEMORY.md regenerated")
        elif a.cmd == "list":
            for d in load_all():
                print(f"{d['meta']['id']:40} {d['meta'].get('scope','?'):8} "
                      f"{d['meta'].get('status','?')}")
    except OkfError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
