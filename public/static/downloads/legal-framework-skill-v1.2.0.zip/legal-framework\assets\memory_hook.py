r"""Deterministic Memory hook — raises REFLECTIVE QUESTIONS at the right moments.

Design intent: the hook must NOT assert facts or auto-inject memory. It
inserts a *subjective request* — a self-question — so the model reflects and
decides for itself whether to consult or capture Repository Memory. This is
exactly what you want from an LLM: prompt it to question itself at the right
cadence. Crude keyword detection is therefore fine — we are ASKING a
question, not asserting a conclusion, so being roughly right is enough; the
model makes the judgment.

  SessionStart      -> states the standing reflective posture + fact count.
  UserPromptSubmit  -> injects one compact self-check: consult memory if this is
                       ambiguous / a design|investigation|verification start;
                       and, when the wording suggests it, asks whether to
                       capture a fact (a challenge to a prior outcome, or a
                       CLAUDE.md clarification).

The hook NEVER blocks or errors the prompt: any failure exits 0 silently, and
trivial prompts get nothing (no noise).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Hook stdout is consumed by Claude Code as UTF-8; a Windows console is often
# cp1252, so force UTF-8 (errors=replace) or a non-ASCII char would raise and —
# caught by the safety wrapper — silently drop the whole nudge.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, str(Path(__file__).resolve().parent))

# Wording that HINTS at a memory-creation moment. Not a verdict — just enough to
# raise the question. Tune to taste.
_CHALLENGE = (
    "that's wrong", "thats wrong", "that is wrong", "that's not right",
    "incorrect", "you shouldn't have", "why did you", "i disagree",
    "that's not what", "you missed", "this is a bug", "that's a bug",
    "should have", "not what i", "my intent was", "actually",
)
_CLARIFY = ("claude.md", "constitution", "legislation", "the rule",
            "what i meant", "to clarify", "clarify", "i meant")

# Skip nudging on trivial acknowledgements / very short prompts.
_TRIVIAL = {"yes", "no", "ok", "okay", "thanks", "thank you", "go", "proceed",
            "continue", "sure", "yep", "do it", "push", "commit"}


def _emit(lines: list[str]) -> None:
    if lines:
        print("\n".join(lines))


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        return
    event = data.get("hook_event_name", "")

    if event == "SessionStart":
        try:
            import memory as mem
            n = len(mem.load_all())
        except Exception:
            n = 0
        _emit([
            f"Repository Memory (Common Law) is active — {n} atomic fact(s). "
            "Standing posture: question yourself before acting. At Ambiguity "
            "Events and at the start of design / investigation / verification, "
            "reflect on whether past experience applies and consult memory "
            "(skill: memory-consult) rather than proceeding from the moment. "
            "When you challenge-resolve or clarify a rule, consider capturing a "
            "fact (skill: memory-capture). Recall/CRUD only via scripts/memory.py.",
        ])
        return

    if event != "UserPromptSubmit":
        return

    prompt = str(data.get("prompt", "")).strip()
    low = prompt.lower()
    if len(prompt) < 15 or low.strip(" .!") in _TRIVIAL:
        return   # nothing worth self-questioning here

    # Always raise the consult question — ambiguity can't be keyword-detected,
    # so the model must be the one to judge whether this moment needs memory.
    lines = [
        "↳ Memory reflection: before answering, ask yourself — is this "
        "ambiguous, or the start of design / investigation / verification? If "
        "so, would prior experience improve it? Consult Repository Memory "
        "(skill: memory-consult) before proceeding from memory-of-the-moment.",
    ]
    if any(k in low for k in _CHALLENGE):
        lines.append(
            "  · This may challenge a prior outcome — once you've resolved it, "
            "ask whether to capture the correction (skill: memory-capture, run "
            "ASYNC so the flow keeps moving).")
    if any(k in low for k in _CLARIFY):
        lines.append(
            "  · If this clarifies (does not change) a CLAUDE.md rule, ask "
            "whether to capture the interpretation (skill: memory-capture).")
    _emit(lines)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass   # never disrupt the prompt flow
