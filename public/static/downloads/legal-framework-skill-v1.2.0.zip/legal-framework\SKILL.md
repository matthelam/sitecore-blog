---
name: legal-framework
description: >
  Install, audit, upgrade, or repair the Legal Framework for agent context —
  a Constitution (root CLAUDE.md: values and supreme laws), Legislation
  (per-directory CLAUDE.md), and Common Law (an OKF repository-memory
  system) — in any code repository or Cowork directory. Use for "set up the
  legal framework", "add a constitution", "create legislation", "install
  common law / repository memory", "scaffold my CLAUDE.md structure", "set
  up agent governance for this repo", "port the framework from another
  repo", or a new project that should use the same agent-context pattern —
  even if only one tier is named. Also for checking an install ("audit my
  legal framework") and for UPGRADING one ("upgrade my legal framework",
  "bring this repo up to date", "I've installed a newer version of the
  skill") — upgrades preserve all project content and memory facts. Installs
  the knowledge-exchange layer, so Common Law can be exported to and
  imported from other repositories.
---

# The Legal Framework — installer, auditor, and upgrader

**Framework version: 1.2.0.** Every installation is stamped with the version it
was written by, in `scripts/memory.py` as `FRAMEWORK_VERSION`. That stamp is the
only thing Upgrade mode needs to work out what an existing install is missing.

This skill installs the Legal Framework for agent context
(https://blog.matthelam.com/blog/a-legal-framework-for-agent-context) into a
target repository or Cowork directory, or audits/repairs an existing
installation. The framework has three tiers plus an operating loop:

| Tier | Lives in | Role | Portability |
|---|---|---|---|
| **Constitution** | root `CLAUDE.md` | Values + supreme laws; loaded every session; final fallback | Skeleton is fixed; supreme laws come from the human |
| **Legislation** | per-directory `CLAUDE.md` | Architecture, patterns, and laws for one unit; loaded just-in-time | Shape is fixed; content inferred + confirmed |
| **Common Law** | `memory/` + generated `MEMORY.md` | Accumulated experience as atomic OKF facts (One Key Fact per file) | Machinery is identical everywhere; only scopes + privacy markers are per-project |

The **operating loop** is installed alongside: a reflective hook
(SessionStart + UserPromptSubmit) and three skills — `memory-consult` (before
acting), `memory-capture` (after learning), `task-sense-check` (before saying
"done"). Together: **consult → work → capture → sense-check**.

The **knowledge-exchange layer** (added in framework v1.2.0) makes the Common
Law portable between repositories, and is installed with every framework:

| Skill | Role |
|---|---|
| `knowledge-export` | Select a dimension of this repo's Common Law, reason each fact into *transferable* knowledge, and seal it as `<repo>_<all\|dimension>_<yyyyMMddHHmm>.zip` |
| `knowledge-import` | Bring in a bundle or a foreign `memory/` directory, reconciling every fact against this repo's Constitution and Legislation before anything is written |
| `framework-lint` | Verify the whole framework — the mechanical gates *and* a semantic sweep for contradictions across Common Law, Legislation and Constitution |

Both directions run through `scripts/memory_exchange.py`, which imports
`memory.py` rather than reimplementing it: one OKF gate, shared by local capture,
export staging, and import. Two invariants hold the layer together —
**exports are generalised, never copied verbatim**, and **a fact that conflicts
with the destination's law is never imported**, with the human the only one who
can clear a conflict. `framework-lint` is the closing step of every import and
is also usable on its own.

**Conceptual framing for the user:** Common Law records *Issues, Learnings,
and Resolutions*. Mechanically those map onto the fixed six-tag taxonomy —
Issues → `issue`; Resolutions → `fix`; Learnings → `preference`, `example`,
`verification`, `knowledge`. Explain it with the triple; enforce it with the
six tags. The six-tag set is fixed across all installations because the consult
skill routes searches by tag (investigation → `issue,fix,knowledge`; design →
`preference,issue,knowledge`; verification → `verification,fix`; domain
grounding → `knowledge`). Never invent new tags.

`knowledge` (added in framework v1.1.0) is the Learning that no rule covers: a
domain fact, a system's real behaviour, or a constraint the model did not
previously have and would otherwise re-ask for. It is deliberately distinct from
`example`, which is a *worked interpretation of an existing rule*. Keeping them
separate is what lets the consult skill route domain grounding without dragging
in rule interpretations.

**Amending the taxonomy is a framework-version change, not a local edit.** The
tag set is a closed vocabulary shared by the gate, the capture skill, and the
consult skill's routing table; changing it in one installation silently breaks
retrieval parity with every other. If a genuinely new category is ever needed,
it is added to all three at once, given a consult route (a tag nothing queries
is dead storage), and shipped as a version bump with a migration line — never
introduced per-project.

---

## Phase 0 — Detect the situation, then load the right reference

Read the target's root `CLAUDE.md` (if any).

- If it declares the Legal Framework (mentions "Legal Framework" or the
  Constitution/Legislation/Common Law tiers) → an **existing install**. Read
  `FRAMEWORK_VERSION` from `scripts/memory.py`:
  - **older than this skill's version, or absent** → **upgrade mode** (an
    absent stamp means pre-1.1.0);
  - **equal** → **audit mode**;
  - **newer** → stop and say so; do not downgrade an install that was written
    by a later version of this skill.
- Otherwise → **fresh install**. If a root `CLAUDE.md` exists with other
  content, plan to *fold it in*, not overwrite: existing rules become
  candidate values/laws/legislation and are presented as such at sign-off.

Then read exactly the reference you need — they are mutually exclusive, and
reading the wrong one anchors you on the wrong workflow:

| Situation | Read | Contains |
|---|---|---|
| Fresh install | `references/install.md` | Phases 1–5: evidence scan, interview, one sign-off, the file manifest, verification |
| Existing install, same version | `references/audit-and-upgrade.md` | Audit-and-repair mode |
| Existing install, older version | `references/audit-and-upgrade.md` | Upgrade mode + the migration ledger |

Supporting references, loaded when the phase that needs them says so:
`references/interview-guide.md` (the question bank),
`references/constitution-template.md` and `references/legislation-template.md`
(the two authoring shapes).

**The guiding principle of every mode:** infer, then ask only what evidence
cannot answer, then confirm the whole picture once. A wrong guess in the
Constitution compounds into every future session, so inference never silently
commits — but the human's time is spent only on questions about intent, not
structure.

## Things this skill never does

- Scaffold before the Phase 3 sign-off.
- Overwrite a pre-existing CLAUDE.md or settings.json (fold in / merge).
- Invent supreme laws the human didn't state, or tags outside the taxonomy —
  the taxonomy widens only by a version bump applied everywhere, never per-project.
- Overwrite project content during an upgrade: `SCOPES`, `PRIVACY_MARKERS`,
  supreme laws, Legislation, and `memory/` facts survive every migration.
- Downgrade an installation stamped with a newer version than the skill.
- Hand-edit `memory/` or `MEMORY.md` — even during install, facts go through
  `memory.py`.
- Move knowledge between repositories by copying files. Export generalises,
  import reconciles against the destination's law, and a conflicting fact is
  never written — copying `memory/` across skips all three.
- Put personal/secret content anywhere in the scaffolded files: the framework
  is designed to be shareable.
