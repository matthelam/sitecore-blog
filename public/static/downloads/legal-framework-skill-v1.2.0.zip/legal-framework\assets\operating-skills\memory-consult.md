---
name: memory-consult
description: >
  Consult Repository Memory (the Common Law tier) BEFORE acting — at Ambiguity
  Events and at the start of investigation, design, and verification work. Use
  when: a requirement is unclear, under-specified, or you are guessing; you are
  about to investigate a bug or unexpected behaviour; you are designing or
  choosing between approaches; you are starting a verification / QA pass; or you
  need a domain fact about how this workspace actually works. Runs
  scripts/memory.py search and applies the relevant prior facts before you
  proceed, so past experience shapes the work instead of being rediscovered.
---

# Consult memory before acting

Repository Memory is the accumulated experience of this codebase as atomic OKF
facts under `memory/`. Query it through the single point of contact:

    {{PYTHON}} scripts/memory.py search "<keywords>" [--tags ...] [--scope <unit>] [--top 5]

## Pick the mode, then query

| Situation (why you invoked) | Tag filter | What to do with hits |
|---|---|---|
| **Ambiguity** — unclear/under-specified requirement | *(none — broad)* | Resolve the ambiguity using the fact; if none applies, state the assumption you're making so it's visible. |
| **Investigation** — a bug / unexpected behaviour | `--tags issue,fix,knowledge` | Check whether this exact class of problem is already known and how it was fixed before reproducing from scratch. |
| **Design** — choosing an approach | `--tags preference,issue,knowledge` | Steer the design away from recorded pitfalls and toward established preferences; note which fact shaped the choice. |
| **Domain grounding** — you need a fact about how this workspace actually works | `--tags knowledge` | Apply what was previously established rather than re-deriving or re-asking; if nothing is found, ask the user rather than assuming. |
| **Verification** — starting a QA/verify pass | `--tags verification,fix` | Fold prior verification lessons into the plan (what broke before, what to re-check). |

Scope the query with `--scope {{SCOPES}}` when the work is in one unit; omit
for cross-cutting concerns (repo-scoped facts always match).

## Rules

- **Search before you guess.** One query is cheap; a rediscovered pitfall is not.
- Cite the fact you applied (its id) in your reasoning so the influence is traceable.
- If nothing relevant is found, proceed — but say so, and if the work later
  yields a durable lesson, capture it (see the `memory-capture` skill).
- Never hand-read or hand-edit `memory/`; recall is read-only through `memory.py`.
