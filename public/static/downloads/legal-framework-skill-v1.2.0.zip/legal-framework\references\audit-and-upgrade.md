# Audit, repair, and upgrade

Reached from the legal-framework SKILL.md after Phase 0 detects an **existing
install**:

- version **equal** to the skill's → audit mode;
- version **older or absent** → upgrade mode, then audit what upgrade did not
  cover;
- version **newer** → stop; never downgrade an install written by a later
  version of the skill.

Both modes share one discipline: report first, get one approval, then change
only what actually drifted.

---

## Audit and repair (existing installation)

Walk the file manifest in `references/install.md` (Phase 4 — Scaffold)
against what is installed, and report each row as
present / missing / drifted. Checks that matter beyond existence:

- `memory.py lint` passes; `MEMORY.md` is fresh (lint reports staleness).
- Hook wired in `.claude/settings.json` and exits 0 on a `{}` stdin.
- The six skills exist and their `SCOPES`/python paths match `memory.py`.
- Constitution's Legislation index matches the CLAUDE.md files on disk.
- Facts in `memory/` were not hand-edited into non-compliance (lint catches).
- `memory_exchange.py structure` runs and reports no
  `scopes_used_but_undeclared`; `.exchange/` is gitignored.

Audit covers *mechanical* integrity. For contradictions between the tiers —
a fact that argues against a supreme law, Legislation that has drifted from the
Constitution — run the installed `framework-lint` skill; that is the semantic
pass, and no amount of file-manifest checking substitutes for it.

Report the gaps, get one approval, repair only what drifted — surgical
changes; leave compliant files byte-identical.

## Upgrade an existing installation

Installs age. This mode forward-migrates the **machinery** of an older install
to the current framework version while leaving everything the project earned —
its laws, its content, its accumulated facts — untouched.

**The dividing line.** Machinery is identical in every installation and is
replaced wholesale; project content is unique and is never rewritten:

| Forward-migrated (replace **or add**) | Never touched (preserve) |
|---|---|
| `scripts/memory.py` machinery + `FRAMEWORK_VERSION` | `SCOPES`, `PRIVACY_MARKERS` in its config block |
| `scripts/memory_hook.py`, `scripts/memory_exchange.py` | The Constitution's values and supreme laws |
| The six operating skills | All Legislation content (`<unit>/CLAUDE.md`) |
| Hook wiring in `.claude/settings.json` | Every fact in `memory/`, including imported ones and their provenance; all other settings.json keys |

### Steps

1. **Read the installed version** from `scripts/memory.py`
   (`FRAMEWORK_VERSION`; absent = pre-1.1.0).
2. **Select the migrations** from the ledger below whose version is greater than
   the installed one, in order.
3. **Diff before proposing.** Walk the **full file manifest** from
   `references/install.md` (Phase 4 — Scaffold), not just
   the files the target already has — a migration may *add* machinery, and a
   file that does not exist yet will never show up in a diff of what does.
   Report each manifest row as absent / current / drifted / locally-modified:
   - **absent** → a new file this version introduces; write it, templating it
     from the existing install.
   - **locally-modified** → the one case that needs a human decision. Surface
     the difference and ask; never silently discard a local change.
4. **One sign-off.** Present: installed version → target version, the migration
   lines that will apply, the file-by-file diff summary, and an explicit
   statement of what is being preserved. Wait for approval.
5. **Apply**, re-templating `{{PYTHON}}`, `{{SCOPES}}` and
   `{{PROJECT_DIMENSIONS}}` from the *existing* install — read those values off
   the current files; do not re-interview.
6. **Verify** exactly as install Phase 5 does (`references/install.md`):
   `import yaml`, the full-CRUD smoke test, the exchange round-trip,
   the hook check, plus `memory.py lint` to confirm every pre-existing fact
   still validates against the new gate. **A migration that invalidates existing
   facts is a failed migration** — roll back that step and report it.
7. **Report**: version moved, migrations applied, files changed, files
   preserved, and the smoke-test/lint results.

### Migration ledger

| Version | Change | Migration |
|---|---|---|
| **1.1.0** | Taxonomy extended to six tags: `knowledge` added for net-new domain facts. `memory-capture` gains Mode 3 (async capture of knowledge the conversation shows the model lacked); `memory-consult` gains a `knowledge` route and folds the tag into its investigation and design filters. | Append `"knowledge"` to `TAGS` in `scripts/memory.py`; add `FRAMEWORK_VERSION = "1.1.0"`; replace the `memory-capture` and `memory-consult` skills. **Backward-compatible** — the tag set only widens, so every existing fact still validates and no fact needs rewriting. |
| **1.2.0** | Knowledge-exchange layer added: Common Law becomes portable between repositories. New `scripts/memory_exchange.py` (export staging + sealing, import scan/plan/apply, framework structure inventory) sharing `memory.py`'s OKF gate, plus three skills — `knowledge-export`, `knowledge-import`, `framework-lint`. Facts may now carry optional provenance keys (`origin_repo`, `origin_id`, `origin_scope`, `imported`, `merged_from`). | Write `scripts/memory_exchange.py`; write the three new skills with `{{PYTHON}}` filled from the existing install; add `.exchange/` to `.gitignore`; set `FRAMEWORK_VERSION = "1.2.0"`. **Backward-compatible** — no change to `TAGS`, `SCOPES`, or the validator, and the new frontmatter keys are additive and optional, so every existing fact still validates untouched. After migrating, run the newly installed `framework-lint` once: an install that has been accumulating facts for a while has never had a semantic cross-tier check, and the first run often finds real drift. |

New migrations are appended here as versions ship; each states its change, its
mechanical steps, and whether it is backward-compatible. A migration that would
invalidate existing facts must ship with a rewrite step, not a bare gate change.

### Upgrading this skill itself

The installed copy of *this skill* (in the Claude app, or `.claude/skills/`) is
not self-updating — a newer bundle has to be installed by the user. When the
user provides one, treat the version in its `SKILL.md` header as authoritative
and run Upgrade mode against each target repository they name. Installs upgrade
independently; there is no central registry, and an install left on an older
version keeps working — the ledger is what lets it catch up later.
